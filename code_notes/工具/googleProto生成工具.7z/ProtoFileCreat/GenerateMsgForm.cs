﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ProtoFileCreat
{
    public partial class GenerateMsgForm : Form
    {
        public GenerateMsgForm()
        {
            InitializeComponent();
        }

        public static void Show(string text, IWin32Window parent = null)
        {
            GenerateMsgForm form = new GenerateMsgForm();
            form.memoEdit1.Text = text;

            form.ShowDialog(parent);
        }
    }
}
