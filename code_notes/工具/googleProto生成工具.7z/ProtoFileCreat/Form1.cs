﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Diagnostics;
using System.IO;
using System.IO.Compression;
using System.Threading;


namespace ProtoFileCreat
{
    public partial class Form1 : Form
    {
        private string m_cFileLoacion;  //存放路径
        List<string> m_Folder = new List<string>();   //ini中保存的附加目录

        public Form1()
        {
            InitializeComponent();

            //设置数据源的说明信息
            this.dt.Columns.Add("文件列表", System.Type.GetType("System.String"));

            //默认的生成文件目录
            m_cFileLoacion = AppDomain.CurrentDomain.BaseDirectory;//获取基目录，它由程序集冲突解决程序用来探测程序集。
            m_cFileLoacion += "ProtoFile";
            this.barEditItem1.EditValue = m_cFileLoacion;
            this.barEditItem1.Caption = m_cFileLoacion;
        }

        private void barButtonItem1_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Multiselect = true;
            openFileDialog.Filter = "All files (*.*)|*.*|proto files (*.proto)|*.proto";
            openFileDialog.FilterIndex = 2;
 
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                string[] fNames = openFileDialog.FileNames;
                AddFileInfo(fNames);

            }
        }

        private bool CheckDataVisible()
        {
            if (dt.Rows.Count < 1)
            {
                MessageBox.Show("请选择要转化的proto文件!!");
                return false;
            }


            if (!Directory.Exists(m_cFileLoacion))//如果不存在就创建file文件夹
            {
                Directory.CreateDirectory(m_cFileLoacion);//创建该文件夹
            }

   
            return true;
        }

        private void ReadIniInfos()
        {
            m_Folder.Clear();
            //得到应用程序根目录
            string FileLoacion = AppDomain.CurrentDomain.BaseDirectory;

            //打开Ini 配置文件
            FileStream fs = new FileStream(FileLoacion + "Folder.ini", FileMode.OpenOrCreate, FileAccess.Read);

            //为上面创建的文件流创建读取数据流  
            StreamReader read = new StreamReader(fs);

            //设置当前流的起始位置为文件流的起始点  

            read.BaseStream.Seek(0, SeekOrigin.Begin);

            //读取文件  
            while (read.Peek() > -1)
            {
                //读取文件内容保存
                m_Folder.Add(read.ReadLine());
            
            }
            //关闭释放读数据流  
            read.Close();

        }

        //C++文件的生成函数
        private void button1_Click(object sender, EventArgs e)
        {
            if (!CheckDataVisible())
                return;
            transCCFile();
            if (ccFileMove())
            {
                System.Diagnostics.Process.Start("explorer.exe", @m_cFileLoacion);
            }
        }

        private string GetDependFolder()
        {
            StringBuilder builder = new StringBuilder(1024);
            //加载配置文件中的所有路径
            for (int index = 0; index < m_Folder.Count; ++index)
            {
                builder.AppendFormat("-I={0} ", m_Folder[index]);
            }
            return builder.ToString();
        }

        private bool ProcessRunning { get; set; }
        private void openProcessStreamThread(Process p, StringBuilder errOutput)
        {
            this.ProcessRunning = true;
            Thread tErr = new Thread(new ThreadStart(() =>
            {               
                string error = "";
                while (this.ProcessRunning)
                {
                    try
                    {
                        error = p.StandardError.ReadLine();
                    }
                    catch { }
                    if (string.IsNullOrEmpty(error))
                    {
                        continue;
                    }
                    errOutput.AppendLine(error);
                }
            }));
            tErr.Start();

            Thread tOut = new Thread(new ThreadStart(() =>
            {
                while (this.ProcessRunning)
                {
                    try
                    {
                        string outMsg = p.StandardOutput.ReadLine();
                    }
                    catch { }
                }
                Console.WriteLine("Out Cmd Exit!");
            }));
            tOut.Start();
        }

        private void closeProcessStreamThread()
        {
            this.ProcessRunning = false;
        }

        private bool transCCFile()
        {
            this.splashScreenManager1.ShowWaitForm();
            //读取配置文件中的信息
            ReadIniInfos();
       
			System.Diagnostics.Process p = new System.Diagnostics.Process();

			p.StartInfo.FileName = "cmd.exe";
			p.StartInfo.UseShellExecute = false;
			p.StartInfo.RedirectStandardInput = true;
            p.StartInfo.RedirectStandardOutput = true;
			p.StartInfo.RedirectStandardError = true;
			p.StartInfo.CreateNoWindow = true;    //true表示不显示黑框，false表示显示dos界面 
			p.Start();

            StringBuilder cmdWriter = new StringBuilder(1024);
            StringBuilder errOutput = new StringBuilder(1024);
            // 开启多线程从进程中获取信息
            openProcessStreamThread(p, errOutput);

            string dependencies = GetDependFolder();

            string runDir = AppDomain.CurrentDomain.BaseDirectory;
			//DOS下指定到exe存放路径下;
			p.StandardInput.WriteLine(string.Format("cd {0}", runDir));
			//切找到exe指向的盘中，否则生成不成功
            p.StandardInput.WriteLine(string.Format("{0}", Path.GetPathRoot(runDir)).Trim('\\'));

            string fileName;
			//转换所有的proto文件
            for (int nIndex = 0; nIndex < dt.Rows.Count; ++nIndex)
            {
                cmdWriter.Clear();
				
				fileName = dt.Rows[nIndex][0].ToString();
                this.splashScreenManager1.SendCommand(ProtoFileCreat.WaitForm1.WaitFormCommand.Description,
                                                      string.Format("{0}/{1}:\r\n\r\n{2}", nIndex + 1, dt.Rows.Count, fileName));
               
                string fileDir = Path.GetDirectoryName(fileName);
                //加上所有盘的路径项，保证生成在目标文件下
                cmdWriter.AppendFormat("protoc -I={0} ", fileDir);
                //加载配置文件中的所有路径
                cmdWriter.Append(dependencies);
                // 设置输出目录
                cmdWriter.AppendFormat("--cpp_out={0} {1}", fileDir, fileName);

                p.StandardInput.WriteLine(cmdWriter.ToString());
			}

            p.StandardInput.WriteLine(@"Exit");

            this.splashScreenManager1.SendCommand(ProtoFileCreat.WaitForm1.WaitFormCommand.Description,
                                                  "等待进程退出！");
            p.WaitForExit();
            p.Close();

            closeProcessStreamThread();
            if (errOutput.Length > 0)
            {
                errOutput.AppendLine();
            }

            this.splashScreenManager1.CloseWaitForm();

            bool bRes = true;
            if (errOutput.Length != 0)
            {
                GenerateMsgForm.Show(errOutput.ToString(), this); 
                bRes = false;
            }
   
            return bRes;
        }
    
        private void barEditItem1_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            //存放路径目录设置
             FolderBrowserDialog openFileDialog = new FolderBrowserDialog();
              
             if (openFileDialog.ShowDialog() == DialogResult.OK)
             {
                // C盘操作无效，故判断不能设定C盘
                 if (openFileDialog.SelectedPath.Substring(0, 1).Equals("C"))
                 {
                     MessageBox.Show("不能对C盘进行读写操作");
                     return;
                 }
         
                 m_cFileLoacion = openFileDialog.SelectedPath;
                 this.barEditItem1.EditValue = m_cFileLoacion;
                 this.barEditItem1.Caption = m_cFileLoacion;
             }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (!CheckDataVisible())
                return;
            //转化C#文件
            transCSFlie();
            //移动C#文件到目标文件夹
            if (csFileMove())
            {
                //打开指定的文件夹
                System.Diagnostics.Process.Start("explorer.exe", @m_cFileLoacion);
            }
        }


        private bool transCSFlie()
        {
            this.splashScreenManager1.ShowWaitForm();

            //读取配置文件中的信息
            ReadIniInfos();
            System.Diagnostics.Process p = new System.Diagnostics.Process();

            p.StartInfo.FileName = "cmd.exe";
            p.StartInfo.UseShellExecute = false;
            p.StartInfo.RedirectStandardInput = true;
            p.StartInfo.RedirectStandardOutput = true;
            p.StartInfo.RedirectStandardError = true;
            p.StartInfo.CreateNoWindow = true;    //true表示不显示黑框，false表示显示dos界面 
            p.Start();

            StringBuilder cmdWriter = new StringBuilder(1024);
            StringBuilder errOutput = new StringBuilder(1024);

            openProcessStreamThread(p, errOutput);

            string dependencies = GetDependFolder();

            string runDir = AppDomain.CurrentDomain.BaseDirectory;
            //DOS下指定到exe存放路径下;
            p.StandardInput.WriteLine(string.Format("cd {0}", runDir));
            //切找到exe指向的盘中，否则生成不成功
            p.StandardInput.WriteLine(string.Format("{0}", Path.GetPathRoot(runDir)).Trim('\\'));

            string fileName;
            //转换所有的proto文件
            for (int nIndex = 0; nIndex < dt.Rows.Count; ++nIndex)
            {
                cmdWriter.Clear();

                cmdWriter.AppendFormat("protoc --descriptor_set_out=addressbook.protobin ");
                fileName = dt.Rows[nIndex][0].ToString();

                this.splashScreenManager1.SendCommand(ProtoFileCreat.WaitForm1.WaitFormCommand.Description,
                                                      string.Format("{0}/{1}:\r\n\r\n{2}", nIndex + 1, dt.Rows.Count, fileName));

                string fileDir = Path.GetDirectoryName(fileName);
                //加上所有盘的路径项，保证生成在目标文件下
                cmdWriter.AppendFormat("-I={0} ", fileDir);
                //加载配置文件中的所有路径
                cmdWriter.Append(dependencies);
                // 设置输出目录
                cmdWriter.AppendFormat("--include_imports {0}", fileName);

                p.StandardInput.WriteLine(cmdWriter.ToString());
                p.StandardInput.WriteLine("protogen addressbook.protobin");
            }

            p.StandardInput.WriteLine(@"Exit");
            this.splashScreenManager1.SendCommand(ProtoFileCreat.WaitForm1.WaitFormCommand.Description,
                                                  "等待进程退出！");
            p.WaitForExit();
            p.Close();

            closeProcessStreamThread();
            if (errOutput.Length > 0)
            {
                errOutput.AppendLine();
            }

            this.splashScreenManager1.CloseWaitForm();

            bool bRes = true;
            if (errOutput.Length != 0)
            {
                GenerateMsgForm.Show(errOutput.ToString(), this);
                bRes = false;
            }

            return bRes;
        }

        private bool csFileMove()
        {
            string targetDir = m_cFileLoacion + "\\Cs\\";
            if (!Directory.Exists(targetDir))//如果不存在就创建file文件夹
            {
                Directory.CreateDirectory(targetDir);//创建该文件夹
            }

            string exeDir = AppDomain.CurrentDomain.BaseDirectory;
            string srcFile;
            //判断是否生成对应了对应的cs文件
            for (int nIndex = 0; nIndex < dt.Rows.Count; ++nIndex)
            {
                string protoFile = dt.Rows[nIndex][0].ToString();

                //.h文件的名称
                srcFile = string.Format("{0}{1}.cs", exeDir, Path.GetFileNameWithoutExtension(protoFile));
                moveFileToDir(srcFile, targetDir);
            }

            //删除中间文件
            File.Delete(exeDir + "addressbook.protobin");
            //删除中间目录依赖.cs文件
            string[] tempFiles = Directory.GetFiles(exeDir, "*.cs ");
            foreach (string file in tempFiles)
            {
                //删除原文件
                File.Delete(file);
            }

            return true;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (!CheckDataVisible())
                return;

            //转化C++
            transCCFile();
            //移动C#文件到目标文件目录下
            ccFileMove();
            //转化C#
            transCSFlie();
            
            //移动C#文件到目标文件目录下
            if (csFileMove())
            {
                //生成成功时打开指定的文件夹
                System.Diagnostics.Process.Start("explorer.exe", @m_cFileLoacion);
            }
            
        }

        private void AddFileInfo(string[] filePaths )
        {

            string file = filePaths[0];
            string pFileLoad = file.Substring(0, file.LastIndexOf('\\'));
            // C盘操作无效，故判断不能设定C盘
             if (pFileLoad.Substring(0, 1).Equals("C"))
             {
                 MessageBox.Show("不能对C盘进行读写操作");
                 return;
             }
            else
             {
                  m_cFileLoacion = pFileLoad;
                  this.barEditItem1.EditValue = m_cFileLoacion;
                  this.barEditItem1.Caption = m_cFileLoacion;
             }
        
            foreach (string chld in filePaths)
            {
                //判断添加项是否为proto文件
                int n = chld.LastIndexOf('.');
                string pFileType = chld.Substring(n, chld.Length - n);
                if (!pFileType.Equals(".proto"))
                {
                    MessageBox.Show("请确定添加的为proto文件");
                    break;
                }

                //判断重复项
                int nIndex = 0;
                for (; nIndex < dt.Rows.Count; ++nIndex)
                {
                    string fileName = dt.Rows[nIndex][0].ToString();

                    if (chld.Equals(fileName))
                    {
                        MessageBox.Show("已存在对应项，不能重复添加");
                        break;
                    }
                }

                if (nIndex == dt.Rows.Count)
                {
                    this.dt.Rows.Add(chld);
                }
            }

            //加载所有的打开信息
            this.gridControl1.DataSource = dt.DefaultView;
        }

        private void gridControl1_DragEnter(object sender, DragEventArgs e)
        {
           if (e.Data.GetDataPresent(DataFormats.FileDrop))
               e.Effect = DragDropEffects.Link;
           else 
               e.Effect = DragDropEffects.None; 
            
        }

        private void gridControl1_DragDrop(object sender, DragEventArgs e)
        {
            //获取所有拖动的文件
             string[] filePaths = (e.Data.GetData(DataFormats.FileDrop, false) as string[]);
            //判断添加对应项
             AddFileInfo(filePaths);
        }

        private void barButtonItem2_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            Form2 form = new Form2();
            form.Show();
        }


        private void moveFileToDir(string srcFile, string dir)
        {
            try
            {
                if (!File.Exists(srcFile))
                {
                    return;
                }
                string tarFile = dir + Path.GetFileName(srcFile);
                if (File.Exists(tarFile))
                {
                    File.Delete(tarFile);
                }

                File.Move(srcFile, tarFile);
            }
            catch (IOException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private bool ccFileMove()
        {
            string targetDir = m_cFileLoacion + "\\Cpp\\";
            if (!Directory.Exists(targetDir))//如果不存在就创建file文件夹
            {
                Directory.CreateDirectory(targetDir);//创建该文件夹
            }

            string srcFile;
            //判断是否生成对应了对应的cs文件
            for (int nIndex = 0; nIndex < dt.Rows.Count; ++nIndex)
            {
                string protoFile = dt.Rows[nIndex][0].ToString();

                //.h文件的名称
                srcFile = protoFile.Replace(Path.GetExtension(protoFile), ".pb.h");
                moveFileToDir(srcFile, targetDir);

                srcFile = protoFile.Replace(Path.GetExtension(protoFile), ".pb.cc");
                moveFileToDir(srcFile, targetDir);
            }
            return true;
        }

        private void barButtonItem3_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            this.dt.Clear();
        }
    }
}
