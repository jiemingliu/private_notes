﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace ProtoFileCreat
{
    public partial class Form2 : Form
    {
        private bool m_bSave;

        public Form2()
        {
            InitializeComponent();

            //设置数据源的说明信息
            this.dt.Columns.Add("附加目录", System.Type.GetType("System.String"));
            //从配置文件中读取保存的文件目录
            ReadIniInfos();

            m_bSave = true;
        }

  
        private void ReadIniInfos()
        {
            //得到应用程序根目录
            string FileLoacion = AppDomain.CurrentDomain.BaseDirectory;

            //打开Ini 配置文件
            FileStream fs = new FileStream(FileLoacion + "Folder.ini", FileMode.OpenOrCreate, FileAccess.Read);

            //为上面创建的文件流创建读取数据流  
            StreamReader read = new StreamReader(fs);

            //设置当前流的起始位置为文件流的起始点  

            read.BaseStream.Seek(0, SeekOrigin.Begin);

            //读取文件  
            while (read.Peek() > -1)
            {
                //读取文件内容，设置到数据源中
                this.dt.Rows.Add(read.ReadLine());
            }

            //关闭释放读数据流  
            read.Close();

            this.gridControl1.DataSource = dt.DefaultView;

        }

         private void WriteIniInfos()
        {
            //保存目录信息到ini文件中

            //默认的生成文件目录
            string FileLoacion = AppDomain.CurrentDomain.BaseDirectory;

            //打开指定的文件
            StreamWriter sw = File.CreateText(FileLoacion + "Folder.ini");

            int nIndex = 0;
            for (; nIndex < dt.Rows.Count; ++nIndex)
            {
                string fileName = dt.Rows[nIndex][0].ToString();
                sw.WriteLine(fileName);
            }

            sw.Flush();

            sw.Close();

        }

        private void barButtonItem1_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            //添加目录项
            FolderBrowserDialog openFileDialog = new FolderBrowserDialog();
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                string fName = openFileDialog.SelectedPath;

                //判断重复项
                int nIndex = 0;
                for (; nIndex < dt.Rows.Count; ++nIndex)
                {
                    string fileName = dt.Rows[nIndex][0].ToString();

                    if (fName.Equals(fileName))
                    {
                        MessageBox.Show("已存在对应项，不能重复添加");
                        break;
                    }
                }

                if (nIndex == dt.Rows.Count)
                {
                    this.dt.Rows.Add(fName);
                }
            }
           
            m_bSave = false;
        }

        private void barButtonItem2_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            //删除选中项

            this .gridView1 .DeleteSelectedRows ();

            //加载所有的打开信息
            this.gridControl1.DataSource = dt.DefaultView;

            m_bSave = false;
  
        }

        private void barButtonItem3_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
                  WriteIniInfos();
                 m_bSave = true;
        }

        private void Form2_FormClosing(object sender, FormClosingEventArgs e)
        {   
                if (!m_bSave)
                {
                    if (MessageBox.Show("是否对目录改变进行保存？", "提示", MessageBoxButtons.OKCancel) == DialogResult.OK)
                    {
                        WriteIniInfos();
                    }
                }
        }
    }
}
